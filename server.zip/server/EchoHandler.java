/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class EchoHandler extends Thread 
{
    int num = 0;
    Socket serv;
    
    EchoHandler(Socket serv, int no)
    {
      this.serv = serv;
      this.num = no;
    }        
    public void run()
    {
       try
       {
           DataInputStream din;
       
            din = new DataInputStream(serv.getInputStream());
       
           DataOutputStream dout;
        
            dout = new DataOutputStream(serv.getOutputStream());
            String str = "dd";
            do
            {    
                
                    str = ( String)din.readUTF();
                
                   System.out.println("messag from client= "+num +str);  
                
                    dout.writeUTF(str);   //echo it
                
           }while(!str.equals("bye"));
           serv.close();
        } 
       catch (IOException ex)
       {
            Logger.getLogger(EchoHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
        
}
